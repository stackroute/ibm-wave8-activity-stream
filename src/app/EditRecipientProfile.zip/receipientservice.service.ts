import { Injectable } from '@angular/core';
import {HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ReceipientserviceService {
  private _registerUrl = "http://localhost:8084/api/v1/owner";

  private savedReceipient:any;
  private updatedRecipient:any;

  constructor(private http: HttpClient) { }

  saveReceipient(receipient) {
    this.savedReceipient = this.http.post<any>(this._registerUrl,receipient);
    console.log(this.savedReceipient);
    return this.savedReceipient;

  }

  getRecipient(value):any{
   
      return this.http.get('http://localhost:8084/api/v1/owner/nandu');
  
  }

  updateRecipient(receipient)
  {
    this.updatedRecipient=this.http.put<any>('http://localhost:8084/api/v1/owner/${receipient.id}',receipient);
    return this.updatedRecipient;
  }

 

}
